package com.nt.daemon.campus_controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nt.daemon.campus_model.Campus;
import com.nt.daemon.campus_repository.CampusRepo;
import com.nt.daemon.exception.ResourceNotFoundException;

@RestController
@RequestMapping("/api")
public class CampusController {

	@Autowired
	private CampusRepo campusRepo;

	// read List Of Campus
	
	@GetMapping("/getcampus")
	public List<Campus> getAllCampus() {
		return campusRepo.findAll();
	}

	// Read campus based on campus id
	
	@GetMapping("/campus/{id}")
	public Campus getCampus(@PathVariable(value = "id") Long campusId) {
		return campusRepo.findById(campusId)
				.orElseThrow(() -> new ResourceNotFoundException("Campus", "id", campusId));				
	}

	// create Campus
	
	@PostMapping("/campus")
	public Campus createCampus(@Valid @RequestBody Campus campus) {
		System.out.println("MIRRRRRRRR");
		return campusRepo.save(campus);
	}

	/*// Delete A campus
	
	@DeleteMapping("/campus")
	public boolean deleteCampus(@PathVariable Long id) {
		campusRepo.deleteById(id);
		return true;
	}*/

	
	  // Delete a campus Based on campus id
	  
	 @DeleteMapping("/notes/{id}")
	    public ResponseEntity<?> deleteNote(@PathVariable(value = "id") Long campusId) {
	        Campus campus =campusRepo .findById(campusId)
	                .orElseThrow(() -> new ResourceNotFoundException("campus", "id", campusId));

	        campusRepo.delete(campus);

	        return ResponseEntity.ok().build();
	    }

	  //   Update Campus Based on Campus Id
	 
	  
}