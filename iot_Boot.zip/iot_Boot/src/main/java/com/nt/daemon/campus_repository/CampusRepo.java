package com.nt.daemon.campus_repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nt.daemon.campus_model.Campus;

@Repository
public interface CampusRepo extends JpaRepository<Campus, Long> {




	
	
	
	
	
}
